function pca_xdata = proj_PCA(pca, xdata, PCA_dim)

if nargin < 3
   e_vector = pca.e_vector; 
else
   e_vector = pca.e_vector(:, 1:PCA_dim);
end

%mean_xdata = mean(xdata,2);
xdata_no_mean = xdata - repmat(pca.mean, [1,size(xdata,2)]);

pca_xdata = e_vector'*xdata_no_mean;

end