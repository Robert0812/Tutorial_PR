function pca = apply_PCA(xdata_trn, PCA_dim)
% apply PCA to a training set

if nargin < 2
   PCA_dim = min(size(xdata_trn) - [0, 1]);
end

mean_xdata = mean(xdata_trn,2);
xdata_no_mean = xdata_trn - repmat(mean_xdata, [1, size(xdata_trn,2)]);

scater_train = xdata_no_mean*xdata_no_mean';
scater_train = double(scater_train);

[e_vector, e_value] =  eigs(scater_train, PCA_dim, 'la');

pca.e_vector = e_vector;
pca.e_value = diag(e_value);
pca.mean = mean_xdata;

end