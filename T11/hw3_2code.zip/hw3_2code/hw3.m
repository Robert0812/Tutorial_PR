load 3_2.mat

%% 1.1 mean face

mean_trn = mean(Train, 2);
figure(1)
imshow(reshape(mean_trn, [41, 27]))

%% 1.2 PCA 

pca = apply_PCA(Train);
figure(2)
plot(pca.e_value);

last = find(pca.e_value < 0.1, 1);
figure(3)
for i = 1:10
   subplot(2, 10, i);
   imshow(reshape(pca.e_vector(:, i), [41, 27]), [])
   subplot(2, 10, i+10);
   imshow(reshape(pca.e_vector(:, last - 10 + i), [41, 27]), [])
end
% The first 10 eigenfaces capture the main variations in the training set,
% including, lighting variations, expression variations, and identity
% variations. However, the last 10 eigenfaces captures the noises in the
% face image


%% 1.3 PCA to gallery and test, and compute recognition accuracy w.r.t different PCA_dim

T = 100; % test T trials
PCA_dims = floor(linspace(1, numel(pca.e_value), T));
sqdist_pw = @(A, B) bsxfun(@plus,full(dot(B,B,1)),full(dot(A,A,1))')-full(2*(A'*B));
acc = zeros(1, T);
for i = 1:T
    N = PCA_dims(i);
    gdata = proj_PCA(pca, Gallery, N);
    qdata = proj_PCA(pca, Test, N);
    pwdist = sqdist_pw(gdata, qdata);
    acc(i) = get_acc(pwdist);
end
pwdist = sqdist_pw(Gallery, Test);
acc_pix = get_acc(pwdist);

figure(4);
plot(acc); hold on;
plot(ones(1, T)*acc_pix);


%% 2.1 Intral-personal subspace compared to PCA subspace
dX = Train(:, 1:2:end) - Train(:, 2:2:end);
scatter_train = double(dX*dX');

[e_vector, e_value] =  eigs(scatter_train, size(dX, 2), 'la');
intra.e_vector = e_vector;
intra.e_value = diag(e_value);

figure(5)
for i = 1:10
   subplot(2, 10, i);
   imshow(reshape(intra.e_vector(:, i), [41, 27]), []);
   subplot(2, 10, i+10);
   imshow(reshape(pca.e_vector(:, i), [41, 27]), []);
end

%% 2.3 DIFS fast
L = intra.e_vector./repmat(sqrt(intra.e_value(:))', size(intra.e_vector, 1), 1);

T = 100;
PCA_dims = floor(linspace(1, numel(intra.e_value), T));
acc = zeros(1, T);
for i = 1:T
    N = PCA_dims(i);
    M = L(:, 1:N)*L(:, 1:N)' + eye(size(L, 1))*1e-10;
    pwdist = sqdistance(Gallery, Test, M);
    acc(i) = get_acc(pwdist);
end
pwdist = sqdist_pw(Gallery, Test);
acc_pix = get_acc(pwdist);

figure(6);
plot(acc); hold on;
plot(ones(1, T)*acc_pix);


%% 3.1 PCA + FLD
% get Sb and Sw
dim = size(Train, 1);
Xk_mean = (Train(:, 1:2:end) + Train(:, 2:2:end))./2;
Sb = zeros(dim, dim);
Sw = zeros(dim, dim);
for k = 1:size(Xk_mean, 2)
    Sb = Sb + 2*(Xk_mean(:, k) - mean(Train, 2)) * (Xk_mean(:, k) - mean(Train, 2))';
    Sw = Sw + (Train(:, 2*k-1) - Xk_mean(:, k)) * (Train(:, 2*k-1) - Xk_mean(:, k))';
    Sw = Sw + (Train(:, 2*k) - Xk_mean(:, k)) * (Train(:, 2*k) - Xk_mean(:, k))';
end
pca = apply_PCA(Train);

T = 20;
n_pca_max = size(Train, 2) - max(Train_Label); % n-c
n_fld_max = max(Train_Label) - 1; % c-1
dp = floor(linspace(10, n_pca_max, T));
dl = floor(linspace(10, n_fld_max, T));
acc = zeros(T, T);  
for p = 1:T
    for l = 1:T
        dim_dp = dp(p);
        dim_dl = dl(l);
        if dim_dl >= dim_dp-1
            continue;
        end
        w_pca = pca.e_vector(:, 1:dim_dp);
        Sw_ = w_pca' * Sw * w_pca;
        Sb_ = w_pca' * Sb * w_pca;        
        
        [e_vector, e_value] = eigs(Sw_\Sb_, dim_dl, 'lr');
        w_fld = e_vector;  
        w_opt = w_pca * w_fld;
       
        gdata = w_opt'*Gallery;
        qdata = w_opt'*Test;
        pwdist = sqdist_pw(gdata, qdata);
        acc(p, l) = get_acc(pwdist);
        fprintf('dp:%d, dl:%d, acc: %.2f%%\n', dp(p), dl(l), acc(p,l)*100);
    end
end
figure(7);
surf(acc);
