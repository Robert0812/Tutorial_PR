function acc = get_acc(pwdist)
% assume id labels are the same

[~, order] = sort(pwdist);
match = (order(1, :) == 1:size(pwdist, 2));
acc = sum(match)/size(pwdist, 2);

end